nums = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# AI-suggested refactor: use a list comprehension instead of an explicit loop
squares = [i * i for i in nums]

print(squares)


